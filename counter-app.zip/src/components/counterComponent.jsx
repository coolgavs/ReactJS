import React, { Component } from "react";
class Counter extends Component {
  componentDidUpdate(prevProps, PrevState) {
    console.log("prevProps", prevProps);
    console.log("prevState", PrevState);
  }
  componentWillUnmount() {
    console.log("Couner - UnMount");
  }
  // constructor(){
  //     super();//Base Constructor
  //  this.handleIncrement=  this.handleIncrement.bind(this);
  // }
  // handleIncrement = () => {
  //   this.setState({ value: this.state.value + 1 });
  // };

  styles = {
    fontSize: 20,
    fontWeight: "bold",
  };

  renderTags() {
    //        if(this.state.tags.length === 0) return <p>There are no tags</p>;
    //return <ul>{this.state.tags.map(tag => <li key={tag}>{tag}</li>)}</ul>;
  }

  render() {
    console.log("Counter - rendered");
    //console.log(this.props);
    //let classes = this.getBadgeClasses();
    //React.createElement('div');
    //{this.state.tags.length === 0 && "Please create new Tag!"}
    //<button onClick={this.handleIncrement}
    //{this.renderTags()}
    //{this.props.children}
    /*{ <ul>
                {this.state.tags.map(tag => <li key={tag}>{ tag }</li>)}
         </ul> }*/
    return (
      <div>
        <span style={this.styles} className={this.getBadgeClasses()}>
          {this.formatCount()}
        </span>
        <button
          //onClick={() => this.handleIncrement()}
          onClick={() => this.props.onIncrement(this.props.counter)}
          className="btn btn-secondary btn-sm"
        >
          Increment
        </button>
        <button
          //onClick={() => this.handleDelete()}
          onClick={() => this.props.onDelete(this.props.counter.id)}
          className="btn btn-danger sm m-2"
        >
          Delete
        </button>
      </div>
    );
  }
  getBadgeClasses() {
    let classes = "badge m-2 badge-";
    classes += this.props.counter.value === 0 ? "warning" : "primary";
    return classes;
  }

  formatCount() {
    const { value: count } = this.props.counter; //removed local state encounter
    return count === 0 ? "Zero" : count;
  }
}

export default Counter;
