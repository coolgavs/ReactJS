import React, { Component } from "react";
import Counter from "./counterComponent";

class Couters extends Component {
  //<h4>Counter #{counter.id}</h4>
  render() {
    console.log("Counters - rendered");
    const { onReset, counters, onDelete, onIncrement } = this.props; //Destructuring
    return (
      <div>
        <button onClick={onReset} className="btn-primary btn-small m-2">
          Reset
        </button>
        {counters.map((counter) => (
          <Counter
            key={counter.id}
            onDelete={onDelete}
            onIncrement={onIncrement}
            counter={counter}
          />
        ))}
      </div>
    );
  }
}

export default Couters;
